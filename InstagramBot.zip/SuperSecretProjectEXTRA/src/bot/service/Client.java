package bot.service;

import bot.data.ClientData;    
import io.github.bonigarcia.wdm.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.support.ui.*;

import java.time.*;
import bot.data.*;


public class Client {

    private WebDriver driver;
    private ProxyManager proxyManager;
    private final ClientData clientData;

    public Client(ClientData clientData) {
        this(clientData,null);
    }
    
    public Client(ClientData clientData, ProxyManager proxyManager) {
        this.clientData = clientData;
        this.proxyManager = proxyManager;
        initializeWebDriver();
    }

    private void initializeWebDriver() {
        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-blink-features=AutomationControlled");
        options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
        options.setExperimentalOption("useAutomationExtension", false);
        options.addArguments("--disable-gpu"); //improves stability
        options.addArguments("--no-sandbox"); //improves stability
        options.addArguments("--start-maximized");
        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--disable-dev-shm-usage");
        // options.addArguments("--headless");
        
        if (proxyManager != null) {
            String proxyString = proxyManager.getProxyAddress();
            System.out.println(proxyString);
            Proxy proxy = new Proxy();
            proxy.setHttpProxy(proxyString)
                 .setSslProxy(proxyString);
            options.setProxy(proxy);

            // Chrome doesn't support proxy auth directly via options
            if (proxyManager.hasAuthentication()) {
                System.out.println("⚠️ Proxy authentication needs extension or manual workaround.");
                // In production, you'd inject an extension that handles the proxy auth.
            }
        }

        driver = new ChromeDriver(options); //launches chrome
        //printCurrentIP(driver);
    }

    public boolean login() {
    try {
        System.out.println("Navigating to Instagram login page...");
        driver.get("https://www.instagram.com/accounts/login/");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        Thread.sleep(3000); // Give time for elements to render

        WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
        usernameField.clear();
        usernameField.sendKeys(clientData.getUsername());
        Thread.sleep(300);

        WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("password")));
        passwordField.clear();
        passwordField.sendKeys(clientData.getPassword());
        Thread.sleep(300);

        wait.until(driver -> {
            WebElement btn = driver.findElement(By.xpath("//button[@type='submit']"));
            return btn.isEnabled();
        });

        WebElement loginButton = driver.findElement(By.xpath("//button[@type='submit']"));
        loginButton.click();
        System.out.println("Clicked login button.");

        Thread.sleep(5000); // Wait for redirect

        try {
            WebElement saveInfoButton = wait
                .withTimeout(Duration.ofSeconds(5))
                .until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div[1]/div[1]/div[1]/section/main/div/div/section/div/button")));
            saveInfoButton.click();
            System.out.println("Clicked 'Bilgileri Kaydet' button.");
            Thread.sleep(2000); // Give time for next page to load
        } catch (TimeoutException e) {
            System.out.println("No 'Bilgileri Kaydet' prompt appeared.");
        }

        String currentUrl = driver.getCurrentUrl();
        if (currentUrl.contains("/accounts/login/") || currentUrl.contains("/challenge/")) {
            System.err.println("Login failed or challenge required. Current URL: " + currentUrl);
            System.err.println("Full Page Source:\n" + driver.getPageSource());
            return false;
        } else {
            System.out.println("Login successful! Current URL: " + currentUrl);
            return true;
        }

    } catch (Exception e) {
        System.err.println("An error occurred during login: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}

    public WebDriver getDriver() {
        return driver;
    }
    
    public static void printCurrentIP(WebDriver driver) {
        try {
            driver.get("https://api.ipify.org");
            Thread.sleep(2000);
            System.out.println("🔎 Current IP: " + driver.getPageSource());
        } catch (Exception e) {
            System.out.println("⚠️ Unable to get IP: " + e.getMessage());
        }
    }

    public void quitDriver() {
        if (driver != null) {
            driver.quit();
            System.out.println("WebDriver closed.");
        }
    }}