package bot.service;

import java.awt.AWTException;  
import java.awt.Robot;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.*;
import java.time.*; 
import java.util.List;
import java.util.*;
import java.util.stream.Collectors;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;

import bot.data.*;

public class FunctionsOfBot {
	
	private Client client;
	private ClientData data;
	private WebDriver driver;
	private ProxyManager proxyManager;
    private int commented =0;
    private int liked = 0;
    private boolean commentedState=false;
    private boolean likedState;
    	
	public FunctionsOfBot(ClientData data, ProxyManager proxyManager){
		this.data = data;
		this.proxyManager = proxyManager;
		this.client = new Client(data, proxyManager);
		ConsoleCapture.startCapture();
		
		  System.err.println("❌data()  Giriş başarısız. İşlem iptal edildi."+data);
	}
			
	private boolean ensureLogin() {
        if (!client.login()) {
            System.err.println("❌ensureLogin()  Giriş başarısız. İşlem iptal edildi.");
            return false;
        }
        this.driver = client.getDriver();
        return true;
    }
	
	public Client getClient() {
        return client;
    }
	
	public void commentLikePosts(List<String> comments) {
		
    try {
        if (!ensureLogin()) {
            System.err.println("❌ commentLikePosts Giriş başarısız. İşlem iptal edildi.");
            return;
        }

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JavascriptExecutor js = (JavascriptExecutor) driver;

        // ✅ Read usernames from file
        Set<String> followingUsernames = new LinkedHashSet<>();
        Path filePath = Paths.get(System.getProperty("user.dir"), "SECONDARY USERS TO GET.txt");
        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String username = line.trim();
                if (!username.isEmpty()) {
                    followingUsernames.add(username);
                }
            }
        } catch (IOException e) {
            System.err.println("❌ Error reading usernames file: " + e.getMessage());
            return;
        }

        System.out.println("📄 Loaded usernames from file: " + followingUsernames.size());

        int commented = 0;

        for (String username : followingUsernames) {
            String profileHref = "https://www.instagram.com/" + username + "/";
            driver.get(profileHref);
            Thread.sleep(4000);
            
            for (int i = 0; i < 6; i++) {
                js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
                Thread.sleep(1500); // short wait to allow content to load
            }

            try {
                // Skip private accounts
                List<WebElement> privateTexts = driver.findElements(By.xpath(
                        "//*[contains(text(), 'Bu Hesap Gizli') or contains(text(), 'This Account is Private')]"));
                if (!privateTexts.isEmpty()) {
                    System.out.println("🔒 Gizli hesap veya içerik erişilemez: " + profileHref);
                    continue;
                }

                // Wait for posts to load
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(@href, '/p/')]")));

                // Get all available posts
                List<WebElement> postElements = driver.findElements(By.xpath("//a[contains(@href, '/p/')]"));
                List<String> postUrls = postElements.stream()
                        .map(el -> el.getAttribute("href"))
                        .filter(Objects::nonNull)
                        .distinct()
                        .collect(Collectors.toList());

                System.out.println("🔗 Found " + postUrls.size() + " post(s): " + postUrls);

                // ✅ Dynamic control
                int desiredLimit = Math.min(postUrls.size(), 5);
                int index = 0;

                while (index < desiredLimit && index < postUrls.size()) {
                    String postUrl = postUrls.get(index);
                    driver.get(postUrl);
                    Thread.sleep(3000);

                    try {
                        String randomComment = comments.get(new Random().nextInt(comments.size()));
                        likedState = new Random().nextBoolean();

                        if (likedState) {
                            try {
                                WebElement likeIcon = wait.until(ExpectedConditions.elementToBeClickable(
                                        By.xpath("//section//span//*[name()='svg' and @aria-label='Beğen']")));
                                likeIcon.click();
                                liked++;
                                System.out.println("❤️ Post liked: " + postUrl);
                                System.out.println("Liked amount: " + liked);
                                Thread.sleep(1000);
                            } catch (Exception e) {
                                System.out.println("⚠️ Couldn't like post: " + postUrl + " - " + e.getMessage());
                            }
                        } else {
                            System.out.println("⏩ Skipped liking: " + postUrl);
                        }

                        performCommentAction(driver, wait, randomComment, postUrl);

                        if (commentedState) {
                            int oldLimit = desiredLimit;
                            desiredLimit = Math.min(postUrls.size(), desiredLimit * 2);
                            System.out.println("🆙 Expanded post limit from " + oldLimit + " to " + desiredLimit);
                            commented++;
                        }

                        commentedState = false;

                    } catch (Exception e) {
                        System.out.println("⚠️ Post interaction failed: " + postUrl + " - " + e.getMessage());
                    }

                    index++;
                }

            } catch (TimeoutException e) {
                System.out.println("⚠️ Post links not found on: " + profileHref);
            }
        }

        System.out.println("✅ Toplam yorum yapıldı: " + commented);
        
    } catch (Exception e) {
        System.err.println("❌ Genel hata oluştu: " + e.getMessage());
        e.printStackTrace();
    }
}


		
public void commentOnTodaysReelsOfFollowings(List<String> comments) {
    try {
        if (!ensureLogin()) {
            System.err.println("❌ commentOnTodaysReelsOfFollowings Giriş başarısız. İşlem iptal edildi.");
            return;
        }

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JavascriptExecutor js = (JavascriptExecutor) driver;

        String profileUrl = "https://www.instagram.com/" + data.getUsername() + "/";
        System.out.println(profileUrl);
        driver.get(profileUrl);
        Thread.sleep(4000);

        WebElement followingButton = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//a[contains(@href,'/following')]")));
        followingButton.click();
        Thread.sleep(4000);

        WebElement scrollBox = wait.until(ExpectedConditions.presenceOfElementLocated(
            By.xpath("//div[@role='dialog']//div[contains(@style, 'overflow')]")
        ));

        Set<String> followingUsernames = new LinkedHashSet<>();
        int stableCount = 0;
        int maxStableScrolls = 20;
        int targetCount = 30;

        Robot robot = null;
        try {
            robot = new Robot();
        } catch (AWTException e) {
            System.err.println("⚠️ Robot initialization failed. JS scroll will be used.");
        }

        Point browserPos = driver.manage().window().getPosition();

        // ✅ Move mouse ONCE to center of scrollBox before loop (not inside)
        if (robot != null) {
            @SuppressWarnings("unchecked")
            Map<String, Number> rect = (Map<String, Number>) js.executeScript(
                "var rect = arguments[0].getBoundingClientRect();" +
                "return {left: rect.left, top: rect.top, width: rect.width, height: rect.height};",
                scrollBox);

            int chromeYOffset = 70;

            int centerX = browserPos.getX() + rect.get("left").intValue() + rect.get("width").intValue() / 2;
            int centerY = browserPos.getY() + chromeYOffset + rect.get("top").intValue() + rect.get("height").intValue() / 2 - 45;

            robot.mouseMove(centerX, centerY);
        }

        while (stableCount < maxStableScrolls) {
            int beforeAdd = followingUsernames.size();

            List<WebElement> users = scrollBox.findElements(By.xpath(".//a[contains(@href, '/') and not(contains(@href, '/following'))]"));
            for (WebElement user : users) {
                String href = user.getAttribute("href");
                if (href != null && href.matches("https://www.instagram.com/[^/]+/")) {
                    String username = href.replace("https://www.instagram.com/", "").replace("/", "");
                    if (!username.isEmpty()) {
                        followingUsernames.add(username);
                    }
                }
            }

            if (followingUsernames.size() >= targetCount - 1 && stableCount == maxStableScrolls - 1) {
                System.out.println("⚠️ Almost at expected count. Forcing final scroll...");
                js.executeScript("arguments[0].scrollTop = arguments[0].scrollHeight", scrollBox);
                Thread.sleep(2000);
            }

            try {
                if (robot != null) {
                    for (int i = 0; i < 10; i++) {
                        robot.mouseWheel(1);
                        Thread.sleep(1500);
                    }
                } else {
                    js.executeScript("arguments[0].scrollTop = arguments[0].scrollHeight", scrollBox);
                    Thread.sleep(3000);
                }
            } catch (Exception e) {
                System.err.println("⚠️ Robot scroll failed, using JS.");
                js.executeScript("arguments[0].scrollTop = arguments[0].scrollHeight", scrollBox);
                Thread.sleep(3000);
            }

            try {
                wait.withTimeout(Duration.ofSeconds(5))
                    .until(ExpectedConditions.presenceOfElementLocated(
                        By.xpath("//div[@role='dialog']//div[contains(@class, 'x1iyjqo2') or contains(@aria-label,'Loading')]")
                    ));
                wait.withTimeout(Duration.ofSeconds(10))
                    .until(ExpectedConditions.invisibilityOfElementLocated(
                        By.xpath("//div[@role='dialog']//div[contains(@class, 'x1iyjqo2') or contains(@aria-label,'Loading')]")
                    ));
            } catch (TimeoutException e) {
                System.out.println("⏳ Spinner not found, continuing...");
            }

            Thread.sleep(1000);

            if (followingUsernames.size() == beforeAdd) {
                stableCount++;
                if (stableCount >= 2) {
                    System.out.println("🛑 No new users loaded after 2 attempts, stopping scroll.");
                    break;
                }
            } else {
                stableCount = 0;
            }

            System.out.println("🔄 Users collected so far: " + followingUsernames.size());

            if (followingUsernames.size() >= targetCount) {
                System.out.println("✅ Expected user count reached. Ending scroll.");
                break;
            }
        }

        System.out.println("✅ Final user count: " + followingUsernames.size());

        int commented = 0;

        for (String username : followingUsernames) {

            String profileHref = "https://www.instagram.com/" + username + "/";
            driver.get(profileHref);
            Thread.sleep(4000);

            try {
                wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//a[contains(@href, '/p/')]")
                ));

                List<WebElement> postElements = driver.findElements(
                    By.xpath("//a[contains(@href, '/p/')]")
                );

                List<String> postUrls = postElements.stream()
                    .map(el -> el.getAttribute("href"))
                    .filter(Objects::nonNull)
                    .distinct()
                    .collect(Collectors.toList());

                System.out.println("🔗 Found " + postUrls.size() + " post(s): " + postUrls);

                for (String postUrl : postUrls) {

                    driver.get(postUrl);
                    Thread.sleep(3000);

                    try {
                        WebElement timeElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//time")));
                        String datetime = timeElement.getAttribute("datetime");

                        if (datetime != null) {
                            ZonedDateTime postTime = ZonedDateTime.parse(datetime);
                            ZoneId zoneTR = ZoneId.of("Europe/Istanbul");
                            ZonedDateTime postTimeTR = postTime.withZoneSameInstant(zoneTR);
                            ZonedDateTime nowTR = ZonedDateTime.now(zoneTR);

                            Duration timeDifference = Duration.between(postTimeTR, nowTR);
                            long hoursAgo = timeDifference.toHours();

                            if (hoursAgo >= 0 && hoursAgo <= 48) {
                            	String randomComment = comments.get(new Random().nextInt(comments.size()));
                            	performCommentAction(driver, wait, randomComment, postUrl);
                                commented++;
                            } else {
                                System.out.println("⏱ 24-48 saat arasında değil: " + postUrl + " (" + hoursAgo + " saat önce)");
                            }
                        }
                    } catch (Exception e) {
                        System.out.println("⚠️ Zaman bilgisi alınamadı: " + postUrl);
                    }
                }

            } catch (TimeoutException e) {
                System.out.println("⚠️ Post links not found on: " + profileHref);
            }
        }

        System.out.println("✅ Toplam yorum yapıldı: " + commented);

    } catch (Exception e) {
        System.err.println("❌ Genel hata oluştu: " + e.getMessage());
        e.printStackTrace();
    }
}









   public void commentOnFollowingTextFollowings(List<String> comments) {
	   

    try {
        if (!ensureLogin()) {
            System.err.println("❌ commentOnTodaysReelsOfFollowings Giriş başarısız. İşlem iptal edildi.");
            return;
        }

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JavascriptExecutor js = (JavascriptExecutor) driver;

        Set<String> followingUsernames = new LinkedHashSet<>();
        Path filePath = Paths.get(System.getProperty("user.dir"), "USERS TO GET.txt");
        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String username = line.trim();
                if (!username.isEmpty()) {
                    followingUsernames.add(username);
                }
            }
        } catch (IOException e) {
            System.err.println("❌ Error reading usernames file: " + e.getMessage());
            return;
        }

        System.out.println("📄 Loaded usernames from file: " + followingUsernames.size());

        int commented = 0;

        for (String username : followingUsernames) {
            String profileHref = "https://www.instagram.com/" + username + "/";
            driver.get(profileHref);
            Thread.sleep(4000);

            try {
                // Check for private account warning
                List<WebElement> privateTexts = driver.findElements(By.xpath("//*[contains(text(), 'Bu Hesap Gizli') or contains(text(), 'This Account is Private')]"));
                if (!privateTexts.isEmpty()) {
                    System.out.println("🔒 Gizli hesap veya içerik erişilemez: " + profileHref);
                    continue;
                }

                wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//a[contains(@href, '/p/')]")
                ));

                List<WebElement> postElements = driver.findElements(
                    By.xpath("//a[contains(@href, '/p/')]")
                );

                List<String> postUrls = postElements.stream()
                    .map(el -> el.getAttribute("href"))
                    .filter(Objects::nonNull)
                    .distinct()
                    .collect(Collectors.toList());

                System.out.println("🔗 Found " + postUrls.size() + " post(s): " + postUrls);
                
                int numberOfPostsToCheck = 2 + new Random().nextInt(4); // 2 to 5
                int limit = Math.min(numberOfPostsToCheck, postUrls.size());
                List<String> selectedPostUrls = postUrls.subList(0, limit);

                System.out.println("🎯 " + username + " için ilk " + limit + " post kontrol ediliyor.");


                for (String postUrl : selectedPostUrls) {
                    driver.get(postUrl);
                    Thread.sleep(3000);

                    try {
                        WebElement timeElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//time")));
                        String datetime = timeElement.getAttribute("datetime");

                        if (datetime != null) {
                            ZonedDateTime postTime = ZonedDateTime.parse(datetime);
                            ZoneId zoneTR = ZoneId.of("Europe/Istanbul");
                            ZonedDateTime postTimeTR = postTime.withZoneSameInstant(zoneTR);
                            ZonedDateTime nowTR = ZonedDateTime.now(zoneTR);

                            Duration timeDifference = Duration.between(postTimeTR, nowTR);
                            long hoursAgo = timeDifference.toHours();

                            if (hoursAgo >= 0 && hoursAgo <= 48) {
                            	String randomComment = comments.get(new Random().nextInt(comments.size()));
                            	performCommentAction(driver, wait, randomComment, postUrl);
                                commented++;
                            } else {
                                System.out.println("⏱ 24-48 saat arasında değil: " + postUrl + " (" + hoursAgo + " saat önce)");
                            }
                        }
                    } catch (Exception e) {
                        System.out.println("⚠️ Zaman bilgisi alınamadı: " + postUrl);
                    }
                }

            } catch (TimeoutException e) {
                System.out.println("⚠️ Post links not found on: " + profileHref);
            }
        }

        System.out.println("✅ Toplam yorum yapıldı: " + commented);
        ConsoleCapture.appendLastLineToFile("Last Activity.txt");

    } catch (Exception e) {
        System.err.println("❌ Genel hata oluştu: " + e.getMessage());
        e.printStackTrace();
    }
}
	   
	   
public void commentOnGivenList(List<String> comments) {
    try {
        if (!ensureLogin()) {
            System.err.println("❌ commentOnGivenList Giriş başarısız. İşlem iptal edildi.");
            return;
        }

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JavascriptExecutor js = (JavascriptExecutor) driver;

        Set<String> usernames = new LinkedHashSet<>();
        Path filePath = Paths.get(System.getProperty("user.dir"), "USERS TO GET.txt");
        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String username = line.trim();
                if (!username.isEmpty()) {
                    usernames.add(username);
                }
            }
        } catch (IOException e) {
            System.err.println("❌ Error reading usernames file: " + e.getMessage());
            return;
        }

        System.out.println("📄 Loaded usernames from file: " + usernames.size());
        int commented = 0;

        for (String username : usernames) {
            String profileUrl = "https://www.instagram.com/" + username + "/";
            driver.get(profileUrl);
            Thread.sleep(3000);

            // Scroll 3 times to load more posts
            for (int i = 0; i < 3; i++) {
                js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
                Thread.sleep(2000);
            }

            // Check if profile is private
            List<WebElement> privateTexts = driver.findElements(By.xpath("//*[contains(text(), 'Bu Hesap Gizli') or contains(text(), 'This Account is Private')]"));
            if (!privateTexts.isEmpty()) {
                System.out.println("🔒 Gizli hesap: " + username);
                continue;
            }

            // Fetch post URLs
            List<WebElement> postElements = driver.findElements(By.xpath("//a[contains(@href, '/p/')]"));
            List<String> postUrls = postElements.stream()
                .map(el -> el.getAttribute("href"))
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());

            System.out.println("🔗 " + username + " profilinde bulunan postlar: " + postUrls.size());

            for (String postUrl : postUrls) {
                driver.get(postUrl);
                Thread.sleep(3000);
                try {
                    WebElement timeElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//time")));
                    String datetime = timeElement.getAttribute("datetime");

                    if (datetime != null) {
                        ZonedDateTime postTime = ZonedDateTime.parse(datetime);
                        ZoneId zoneTR = ZoneId.of("Europe/Istanbul");
                        ZonedDateTime postTimeTR = postTime.withZoneSameInstant(zoneTR);
                        ZonedDateTime nowTR = ZonedDateTime.now(zoneTR);

                        Duration timeDifference = Duration.between(postTimeTR, nowTR);
                        long hoursAgo = timeDifference.toHours();

                        if (hoursAgo <= 72) { // 72 saat içinde
                            String randomComment = comments.get(new Random().nextInt(comments.size()));
                            performCommentAction(driver, wait, randomComment, postUrl);
                            commented++;
                        } else {
                            System.out.println("⏱ 72 saatten eski gönderi: " + postUrl);
                        }
                    }
                } catch (Exception e) {
                    System.out.println("⚠️ Zaman bilgisi alınamadı: " + postUrl);
                }
            }
        }

        System.out.println("✅ Toplam yorum yapıldı: " + commented);
        ConsoleCapture.appendLastLineToFile("Last Activity.txt");

    } catch (Exception e) {
        System.err.println("❌ Genel hata oluştu: " + e.getMessage());
        e.printStackTrace();
    }
}



   
   
   
   
   public void followTextUsers() {
    try {
        if (!ensureLogin()) {
            System.err.println("❌ Giriş başarısız. İşlem iptal edildi.");
            return;
        }

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        Path filePath = Paths.get(System.getProperty("user.dir"), "USERS TO GET.txt");

        Set<String> usernames = new LinkedHashSet<>();
        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String username = line.trim();
                if (!username.isEmpty()) {
                    usernames.add(username);
                }
            }
        } catch (IOException e) {
            System.err.println("❌ Error reading file: " + e.getMessage());
            return;
        }

        System.out.println("📋 Total users to follow: " + usernames.size());

        int followed = 0;

        for (String username : usernames) {
            try {
                System.out.println("📍 Visiting @" + username);

                driver.get("https://www.instagram.com/" + username + "/");
                Thread.sleep(3000);

                WebElement followBtn = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("//*[contains(text(), 'Takip Et')]/ancestor::button")));

                followBtn.click();
                followed++;

                System.out.println("✅ Followed @" + username + " (" + followed + ")");
                Thread.sleep(2000 + new Random().nextInt(3000));

            } catch (TimeoutException te) {
                System.out.println("⏭️ Couldn't find follow button for @" + username + " — maybe already followed?");
            } catch (Exception e) {
                System.out.println("⚠️ Error following @" + username + ": " + e.getMessage());
            }
        }

        System.out.println("🎯 Done. Total followed: " + followed);

    } catch (Exception e) {
        System.err.println("❌ Fatal error: " + e.getMessage());
        e.printStackTrace();
    }
}




    
    public void commentOnRandomPosts(List<String> comments) {
    try {
        if (!ensureLogin()) {
            System.err.println("❌ Login failed. Aborting.");
            return;
        }

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        Actions actions = new Actions(driver);

        Set<String> postUrls = new LinkedHashSet<>();
        int maxPosts = 50;

        Thread.sleep(4000);

        int scrollCount = 0;
        while (postUrls.size() < maxPosts && scrollCount < 20) {
            List<WebElement> links = driver.findElements(By.xpath("//a[contains(@href, '/p/')]"));
            for (WebElement link : links) {
                String href = link.getAttribute("href");
                if (href != null && href.matches("https://www.instagram.com/p/[\\w-]+/")) {
                    postUrls.add(href.split("\\?")[0]); // clean tracking params
                }
            }

            // Scroll down to load more posts in main feed
            js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
            Thread.sleep(2500 + new Random().nextInt(1500));
            scrollCount++;
        }

        System.out.println("✅ Collected " + postUrls.size() + " unique post URLs from main feed.");

        int commented = 0;

        for (String postUrl : postUrls) {
            driver.get(postUrl);
            Thread.sleep(3000);

            try {
                String randomComment = comments.get(new Random().nextInt(comments.size()));
                performCommentAction(driver, wait, randomComment, postUrl);
                commented++;
            } catch (Exception d) {
                System.out.println("Error has occurred on post: " + postUrl);
            }
        }

        System.out.println("✅ Total comments made: " + commented);

    } catch (Exception e) {
        System.err.println("❌ Error in commentOnRandomPosts: " + e.getMessage());
        e.printStackTrace();
    }
}


    
    public void followRandom() {
        try {
        	if (!ensureLogin()) {
        		System.err.println("❌ Login failed. Aborting.");
                return;
            }

         // Click on the "Find people" or similar icon/link
         WebElement peopleExplore = driver.findElement(By.xpath("//a[contains(@href, '/explore/people/')]"));
         peopleExplore.click();
         Thread.sleep(5000);

         Set<String> usernames = new HashSet<>();
         int scrolls = 0;

         // Step 1: Scroll and gather usernames
         while (usernames.size() < 30 && scrolls < 20) {
             List<WebElement> profileLinks = driver.findElements(By.xpath("//a[contains(@href, '/')]"));
             for (WebElement link : profileLinks) {
                 String href = link.getAttribute("href");
                 if (href.matches("https://www.instagram.com/[^/]+/")) {
                     String username = href.split("instagram.com/")[1].replace("/", "");
                     usernames.add(username);
                 }
             }

             // Scroll to load more users
             ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,1000)");
             Thread.sleep(1000);
             scrolls++;
         }

         System.out.println("👥 Collected usernames: " + usernames.size());

         int followed = 0;
         for (String username : usernames) {
             if (followed >= 5) break;

             String profileUrl = "https://www.instagram.com/" + username + "/";
             driver.get(profileUrl);
             Thread.sleep(3000);

             // Randomly decide whether to follow this user
             int decision = new Random().nextInt(2) + 1; // 1 or 2
             if (decision == 1) {
                 try {
                	 WebElement followBtn = new WebDriverWait(driver, Duration.ofSeconds(5))
                			    .until(ExpectedConditions.elementToBeClickable(By.xpath("//*[contains(text(), 'Takip Et')]/ancestor::button")));
                			followBtn.click();


                     followBtn.click();
                     followed++;
                     System.out.println("✅ Followed @" + username + " (" + followed + ")");
                     Thread.sleep(2000 + new Random().nextInt(3000));
                 } catch (TimeoutException te) {
                     System.out.println("⏭️ Couldn't find follow button for @" + username);
                 } catch (Exception e) {
                     System.out.println("⚠️ Error following @" + username + ": " + e.getMessage());
                 }
             } else {
                 System.out.println("⏩ Skipped @" + username);
             }
         }

         System.out.println("🎯 Finished. Total followed: " + followed);

     } catch (Exception e) {
         System.err.println("❌ Error: " + e.getMessage());
         e.printStackTrace();
     }
 }
    
    public void performCommentAction(WebDriver driver, WebDriverWait wait, String commentText, String postUrl) {
    int attempts = 0;
    int maxAttempts = 3;

    while (attempts < maxAttempts) {
        try {
            // Step 1: Locate and click the comment box
        	commentedState = true;
            WebElement commentBox = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("form textarea")
            ));
            commentBox.click();
            Thread.sleep(500);
            commentBox.sendKeys(commentText);
            Thread.sleep(1000); // Let the page react to the input

            // Step 2: Wait until "Paylaş" button becomes enabled
            WebElement shareButton = wait.until(driver1 -> {
                WebElement btn = driver1.findElement(By.xpath("//form//div[contains(text(),'Paylaş')]"));
                String classAttr = btn.getAttribute("class");
                boolean isDisabled = classAttr != null && classAttr.toLowerCase().contains("disabled");
                return btn.isDisplayed() && !isDisabled ? btn : null;
            });

            // Step 3: Click the button
            shareButton.click();
            commented++;
            System.out.println("✅ Yorum yapıldı: " + commented + " yorum");
            Thread.sleep(3000 + new Random().nextInt(3000));
            break;

        } catch (StaleElementReferenceException sere) {
            attempts++;
            System.err.println("⚠️ Stale element hatası, tekrar deneniyor (" + attempts + "/" + maxAttempts + "): " + postUrl);
            try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
        } catch (TimeoutException toe) {
            System.err.println("⚠️ Timeout (yorum kutusu veya paylaş butonu): " + postUrl);
            break;
        } catch (Exception e) {
            System.err.println("⚠️ Yorum yapılamadı: " + postUrl + " Hata: " + e.getMessage());
            break;
        }
    }
}
}
