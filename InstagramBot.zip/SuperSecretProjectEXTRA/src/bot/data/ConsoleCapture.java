package bot.data;

import java.io.*;
import java.nio.file.*;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class ConsoleCapture {

    private static final AtomicReference<String> lastLinePrinted = new AtomicReference<>("");

    public static void startCapture() {
        PrintStream originalOut = System.out;

        PrintStream customOut = new PrintStream(new OutputStream() {
            private final ByteArrayOutputStream buffer = new ByteArrayOutputStream();

            @Override
            public void write(int b) throws IOException {
                // Write character immediately to original output
                originalOut.write(b);
                originalOut.flush(); // flush to ensure immediate display

                // Buffer the byte to build the current line
                if (b == '\n') {
                    // When newline, convert buffer to String (trim trailing \r if needed)
                    String line = buffer.toString("UTF-8").trim();
                    if (!line.isEmpty()) {
                        lastLinePrinted.set(line);
                    }
                    buffer.reset();
                } else {
                    buffer.write(b);
                }
            }
        });

        System.setOut(customOut);
    }


    public static String getLastLine() {
        return lastLinePrinted.get();
    }
    
    public static String readLastLineFromFile(String fileName) {
        Path path = Paths.get(fileName);
        try {
            List<String> allLines = Files.readAllLines(path);
            if (allLines.isEmpty()) {
                return null; // or "" depending on preference
            }
            return allLines.get(allLines.size() - 1);
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
            return null;
        }
    }

    public static void appendLastLineToFile(String fileName) {
        String lastLine = getLastLine();
        if (lastLine == null || lastLine.isEmpty()) {
            System.err.println("No line captured yet!");
            return;
        }
        Path path = Paths.get(System.getProperty("user.dir"), fileName);
        try (BufferedWriter writer = Files.newBufferedWriter(path, StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            writer.write(lastLine);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error writing last line to file: " + e.getMessage());
        }
    }
}

