package bot.data;

public class ProxyManager {
	private String proxyHost;
    private int proxyPort;
    private String proxyUsername;
    private String proxyPassword;
    
    public ProxyManager(String proxyHost, int proxyPort) {
        this.proxyHost = proxyHost;
        this.proxyPort = proxyPort;
    }
    
    public ProxyManager(String proxyHost, int proxyPort, String proxyUsername, String proxyPassword) {
    	this.proxyHost = proxyHost;
        this.proxyPort = proxyPort;
        this.proxyUsername = proxyUsername;
        this.proxyPassword = proxyPassword;
    }
    
    public boolean hasAuthentication() {
        return proxyUsername != null && proxyPassword != null;
    }

    public String getProxyAddress() {
        return proxyHost + ":" + proxyPort;
    }

    public String getProxyHost() {
        return proxyHost;
    }

    public int getProxyPort() {
        return proxyPort;
    }

    public String getProxyUsername() {
        return proxyUsername;
    }

    public String getProxyPassword() {
        return proxyPassword;
    }
}
