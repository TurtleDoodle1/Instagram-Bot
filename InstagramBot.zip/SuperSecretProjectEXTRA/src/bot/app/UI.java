package bot.app;

import bot.service.FunctionsOfBot;
import bot.service.Client;

import javax.swing.*;
import java.io.*;
import java.awt.*;
import java.nio.file.*;
import java.util.List;
import bot.data.*;

public class UI {

    JButton buttonToday, buttonRandom, buttonFollow, proceedButton, textButton, buttonUserFollow, stopButton, likefollowButton, buttonUserComment;
    JPanel panel, panelLog;
    JFrame frame, logInFrame;
    JLabel botLabel, name, pass;
    JTextField nameField, commentField, userField;
    JPasswordField passField;

    String username, password, userAns, commentAns;
    
    ProxyManager proxyManager;
    
    FunctionsOfBot func;
    Client client;
    List<String> commentList = List.of(
    	    "hey guys", "@ogrencigundemi gel buraya"
    	);


    public UI() {

        buttonToday = new JButton("Bugünküne yorum yap");
        buttonRandom = new JButton("Ana sayfanın hepsine yorum");
        buttonFollow = new JButton("Karışık takip et");
        buttonUserFollow = new JButton("Texttekileri takip et");
        textButton = new JButton("Texttekilere yorum yap");
        proceedButton = new JButton("Devam et");
        likefollowButton = new JButton("Beğen ve yorum yap");
        buttonUserComment = new JButton("Kullanıcılara yorum yap");
        stopButton = new JButton("DUR");

        botLabel = new JLabel("INSTAGRAM BOT");
        name = new JLabel("Ad");
        pass = new JLabel("Sifre");

        nameField = new JTextField();
        commentField = new JTextField();
        userField = new JTextField();
        passField = new JPasswordField();

        panel = new JPanel();
        panelLog = new JPanel();

        frame = new JFrame();
        logInFrame = new JFrame();
                

        //-------------------------------------------
        
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(500, 650);
            frame.setTitle("Instagram Chatbot");
            frame.setResizable(false);

            panel.setLayout(null);
            panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));

            botLabel.setBounds(140, 10, 250, 100);
            botLabel.setFont(new Font("Arial", Font.BOLD, 25));
            botLabel.setFocusable(false);

            buttonToday.setBounds(40, 90, 380, 50);
            buttonToday.setFont(new Font("Arial", Font.BOLD, 23));
            buttonToday.setFocusable(false);
            buttonToday.addActionListener(e -> {
                disableButtons();
                new Thread(() -> {
                    try {
                        ensureClientInitialized();
                        func.commentOnTodaysReelsOfFollowings(commentList);
                    } finally {
                        enableButtons();
                    }
                }).start();
            });

            buttonRandom.setBounds(40, 155, 380, 50);
            buttonRandom.setFont(new Font("Arial", Font.BOLD, 23));
            buttonRandom.setFocusable(false);
            buttonRandom.addActionListener(e -> {
                disableButtons();
                new Thread(() -> {
                    try {
                        ensureClientInitialized();
                        func.commentOnRandomPosts(commentList);
                    } finally {
                        enableButtons();
                    }
                }).start();
            });

            buttonFollow.setBounds(40, 220, 380, 50);
            buttonFollow.setFont(new Font("Arial", Font.BOLD, 23));
            buttonFollow.setFocusable(false);
            buttonFollow.addActionListener(e -> {
            	disableButtons();
                new Thread(() -> {
                    try {
                        ensureClientInitialized();
                        func.followRandom();
                    } finally {
                        enableButtons();
                    }
                }).start();
            });
            
            textButton.setBounds(40, 285, 380, 50);
            textButton.setFont(new Font("Arial", Font.BOLD, 23));
            textButton.setFocusable(false);
            textButton.addActionListener(e -> {
                disableButtons();
                new Thread(() -> {
                    try {
                        ensureClientInitialized();
                        if (!commentList.isEmpty()) {
                            func.commentOnFollowingTextFollowings(commentList);
                        } else {
                            JOptionPane.showMessageDialog(frame, "Yorum listesi tanımlı değil!", "Hata", JOptionPane.ERROR_MESSAGE);
                        }
                    } finally {
                        enableButtons();
                    }
                }).start();
            });

            
            buttonUserFollow.setBounds(40, 350, 380, 50);
            buttonUserFollow.setFont(new Font("Arial", Font.BOLD, 23));
            buttonUserFollow.setFocusable(false);
            buttonUserFollow.addActionListener(e -> {
            	disableButtons();
                new Thread(() -> {
                    try {
                        ensureClientInitialized();
                        func.followTextUsers();
                    } finally {
                        enableButtons();
                    }
                }).start();
            });
            
            likefollowButton.setBounds(40, 415, 380, 50);
            likefollowButton.setFont(new Font("Arial", Font.BOLD, 23));
            likefollowButton.setFocusable(false);
            likefollowButton.addActionListener(e -> {
                disableButtons();
                new Thread(() -> {
                    try {
                        ensureClientInitialized();
                        if (!commentList.isEmpty()) {
                            func.commentLikePosts(commentList);
                        } else {
                            JOptionPane.showMessageDialog(frame, "Yorum listesi tanımlı değil!", "Hata", JOptionPane.ERROR_MESSAGE);
                        }
                    } finally {
                        enableButtons();
                    }
                }).start();
            });
            
            buttonUserComment.setBounds(40, 480, 380, 50);
            buttonUserComment.setFont(new Font("Arial", Font.BOLD, 23));
            buttonUserComment.setFocusable(false);
            buttonUserComment.addActionListener(e -> {
                disableButtons();
                new Thread(() -> {
                    try {
                        ensureClientInitialized();
                        func.commentOnGivenList(commentList);
                    } finally {
                        enableButtons();
                    }
                }).start();
            });


            
            stopButton.setBounds(160, 550, 120, 40);
            stopButton.setFont(new Font("Arial", Font.BOLD, 23));
            stopButton.setFocusable(false);
            stopButton.addActionListener(e -> {
                disableButtons();

                new Thread(() -> {
                    try {
                        Client client = getClientFromFunc();
                        if (client != null) {
                            ConsoleCapture.appendLastLineToFile("Last Activity.txt");
                            client.quitDriver();
                            func = null;
                        }
                    } finally {
                        enableButtons();
                    }
                }).start();
            });






            panel.add(botLabel);
            panel.add(stopButton);
            panel.add(buttonToday);
            panel.add(buttonRandom);
            panel.add(buttonFollow);
            panel.add(textButton);
            panel.add(buttonUserFollow);
            panel.add(likefollowButton);
            panel.add(buttonUserComment);
            frame.add(panel);
            
            //-----------------------------------------
            
            
            logInFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            logInFrame.setSize(500, 500);
            logInFrame.setTitle("Instagram Login");
            logInFrame.setResizable(false);

            panelLog.setLayout(null);
            panelLog.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));

            name.setFont(new Font("MV Boli", Font.PLAIN, 30));
            name.setBounds(30, 75, 150, 50);

            pass.setFont(new Font("MV Boli", Font.PLAIN, 30));
            pass.setBounds(30, 140, 150, 50);

            nameField.setBounds(200, 90, 250, 40);
            passField.setBounds(200, 155, 250, 40);

 
            proceedButton.setFont(new Font("MV Boli", Font.PLAIN, 20));
            proceedButton.setBounds(175, 230, 150, 50);
            proceedButton.setFocusable(false);
            proceedButton.addActionListener(e -> {
                    String inputUsername = nameField.getText().trim();
                    String inputPassword = new String(passField.getPassword());

                    if (!"".equals(inputUsername) && !"".equals(inputPassword)) {
                        username = inputUsername;
                        password = inputPassword;
                        
                        try (FileWriter writer = new FileWriter("credentials.txt", true)) {
                            writer.write("Username: " + inputUsername + "\n");
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                        
                        try {
                            List<String> previousCredentials = Files.readAllLines(Paths.get("credentials.txt"));
                            for (String line : previousCredentials) {
                                System.out.println("Saved credential: " + line);
                            }
                        } catch (IOException e2) {
                            System.out.println("No saved credentials found yet.");
                        }
                        
                        String lastLine = ConsoleCapture.readLastLineFromFile("Last Activity.txt");
                        if (lastLine != null) {
                            System.out.println("Last activity: " + lastLine);
                        } else {
                            System.out.println("No last activity found yet.");
                        }

                        
                        logInFrame.setVisible(false);
                        frame.setVisible(true);
                        
                    } else {
                    	
                        JOptionPane.showMessageDialog(logInFrame,
                                "Geçersiz kullanıcı adı veya şifre!",
                                "Hata",
                                JOptionPane.ERROR_MESSAGE);
                        nameField.setText("");
                        passField.setText("");
                    }
                });


            panelLog.add(name);
            panelLog.add(pass);
            panelLog.add(nameField);
            panelLog.add(passField);
            panelLog.add(proceedButton);

         logInFrame.add(panelLog);
         logInFrame.setVisible(true);
         frame.setVisible(false);
    }

    private void ensureClientInitialized() {
        if (func == null) {
            ClientData clientData = new ClientData(username, password);
            func = new FunctionsOfBot(clientData, proxyManager);
        }
    }

    private Client getClientFromFunc() {
        if (func != null) {
            return func.getClient();
        }
        return null;
    }
    

    private void disableButtons() {
        SwingUtilities.invokeLater(() -> {
        	buttonToday.setEnabled(false);
        	buttonRandom.setEnabled(false);
            buttonFollow.setEnabled(false);
            buttonUserFollow.setEnabled(false);
            textButton.setEnabled(false);
            likefollowButton.setEnabled(false);
            buttonUserComment.setEnabled(false);
        });
    }

    private void enableButtons() {
        SwingUtilities.invokeLater(() -> {
        	buttonToday.setEnabled(true);
        	buttonRandom.setEnabled(true);
            buttonFollow.setEnabled(true);
            buttonUserFollow.setEnabled(true);
            textButton.setEnabled(true);
            likefollowButton.setEnabled(true);
            buttonUserComment.setEnabled(true);
        });
    }
}